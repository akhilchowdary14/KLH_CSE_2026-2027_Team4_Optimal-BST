# Optimal Binary Search Tree (DSA-3 Project)

Team 4, Section 1 — Data Structures and Algorithms-3 (25CS2103E), K L (Deemed to be) University, 2026-2027

Given `n` distinct keys and their search frequencies, this project builds the binary search tree with the
**minimum expected search cost** using interval **Dynamic Programming**.

## Repository structure

```
├── data/        input datasets (CSV: key,frequency)
├── results/     benchmark results, graph and sample console output
├── src/         source code
│   ├── OptimalBST.java      console program (DP, tree reconstruction, validation, balanced-tree comparison)
│   ├── Benchmark.java       times the O(n^3) DP against Knuth's O(n^2) optimisation
│   ├── GenerateData.java    regenerates the datasets in data/ (fixed seed)
│   └── web_app/             browser version (HTML / CSS / JavaScript)
└── DSA3 _Abstract.pdf
```

## How to run (Java 11 or later; run from the repository root)

```bash
java src/GenerateData.java          # (optional) regenerate data/
java src/OptimalBST.java            # console demo with 3 test cases
java -Xmx1500m src/Benchmark.java   # benchmark -> results/benchmark_results.csv
```

Web version: open `src/web_app/index.html` in a browser (or use VS Code Live Server).

## Datasets (`data/`)

| File | Contents |
|---|---|
| `sample.csv` | The 4-key example from the report: keys 10, 20, 30, 40 with frequencies 4, 2, 6, 3 (optimal cost 26) |
| `dataset_100.csv` … `dataset_4000.csv` | n = 100, 200, 500, 1000, 2000, 4000 keys; keys 1..n, random frequencies 1–1000 (seed 42) |

The sizes stop at 4,000 on purpose: the O(n³) algorithm needs two n × n tables, so much larger inputs
(100,000+) would not fit in memory and would take far too long.

## Results (`results/`)

| n | O(n³) DP (ms) | Knuth O(n²) (ms) | Speed-up | Optimal cost | Balanced-BST cost | Saving |
|---:|---:|---:|---:|---:|---:|---:|
| 100 | 0.60 | 0.17 | 3.5× | 258,761 | 288,470 | 10.30 % |
| 200 | 7.74 | 0.59 | 13.1× | 600,981 | 648,743 | 7.36 % |
| 500 | 109.10 | 8.50 | 12.8× | 1,981,537 | 2,106,082 | 5.91 % |
| 1000 | 680.65 | 31.27 | 21.8× | 4,075,473 | 4,335,717 | 6.00 % |
| 2000 | 11,139.62 | 162.43 | 68.6× | 9,534,622 | 10,064,242 | 5.26 % |
| 4000 | 157,358.33 | 689.28 | 228.3× | 20,855,045 | 21,921,949 | 4.87 % |

![Runtime graph](results/runtime_graph.png)

- Both algorithms return **identical optimal costs on every dataset**, which checks the Knuth implementation.
- Doubling n multiplies the O(n³) time by roughly 6–16×, a little above the ideal 8×, because the inner loop
  reads the cost table column-wise and causes cache misses on large inputs. Knuth's version grows roughly 4–5×
  per doubling, as expected for O(n²).
- The optimal tree is always cheaper than a frequency-blind balanced tree. The saving shown is for uniformly
  random frequencies; it would be larger for more skewed data.
- Timings were measured on one machine in a single run each, so absolute values will differ on yours.

Files: `benchmark_results.csv`, `benchmark_output.txt`, `runtime_graph.png`, `sample_output.txt`.
