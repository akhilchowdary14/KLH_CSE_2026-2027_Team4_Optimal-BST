import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Times the O(n^3) interval DP against Knuth's O(n^2) optimisation on every data/dataset_*.csv file.
 * Run from the repository root:  java -Xmx1500m src/Benchmark.java
 */
public class Benchmark {

    static long[][] cost;
    static int[][] root;

    // ---- standard O(n^3) interval DP (same recurrence as OptimalBST.java) ----
    static long cubic(int[] f) {
        int n = f.length;
        long[] pre = new long[n + 1];
        for (int i = 0; i < n; i++) pre[i + 1] = pre[i] + f[i];
        cost = new long[n][n]; root = new int[n][n];
        for (int i = 0; i < n; i++) { cost[i][i] = f[i]; root[i][i] = i; }
        for (int len = 2; len <= n; len++)
            for (int i = 0; i + len - 1 < n; i++) {
                int j = i + len - 1; long sum = pre[j + 1] - pre[i], best = Long.MAX_VALUE; int br = i;
                for (int r = i; r <= j; r++) {
                    long c = (r > i ? cost[i][r - 1] : 0) + (r < j ? cost[r + 1][j] : 0) + sum;
                    if (c < best) { best = c; br = r; }
                }
                cost[i][j] = best; root[i][j] = br;
            }
        return cost[0][n - 1];
    }

    // ---- Knuth's optimisation: root[i][j-1] <= root[i][j] <= root[i+1][j]  ->  O(n^2) ----
    static long knuth(int[] f) {
        int n = f.length;
        long[] pre = new long[n + 1];
        for (int i = 0; i < n; i++) pre[i + 1] = pre[i] + f[i];
        cost = new long[n][n]; root = new int[n][n];
        for (int i = 0; i < n; i++) { cost[i][i] = f[i]; root[i][i] = i; }
        for (int len = 2; len <= n; len++)
            for (int i = 0; i + len - 1 < n; i++) {
                int j = i + len - 1; long sum = pre[j + 1] - pre[i], best = Long.MAX_VALUE; int br = i;
                for (int r = root[i][j - 1]; r <= root[i + 1][j]; r++) {
                    long c = (r > i ? cost[i][r - 1] : 0) + (r < j ? cost[r + 1][j] : 0) + sum;
                    if (c < best) { best = c; br = r; }
                }
                cost[i][j] = best; root[i][j] = br;
            }
        return cost[0][n - 1];
    }

    // ---- frequency-blind balanced tree (middle key of each range is the root) ----
    static long balanced(int[] f, int lo, int hi, int depth) {
        if (lo > hi) return 0;
        int mid = (lo + hi) / 2;
        return (long) f[mid] * depth + balanced(f, lo, mid - 1, depth + 1) + balanced(f, mid + 1, hi, depth + 1);
    }

    static int[] readFreq(Path p) throws IOException {
        List<String> lines = Files.readAllLines(p);
        int[] f = new int[lines.size() - 1];
        for (int i = 1; i < lines.size(); i++) f[i - 1] = Integer.parseInt(lines.get(i).split(",")[1].trim());
        return f;
    }

    public static void main(String[] args) throws IOException {
        Path dataDir = Paths.get(args.length > 0 ? args[0] : "data");
        Path outDir  = Paths.get(args.length > 1 ? args[1] : "results");
        Files.createDirectories(outDir);

        List<Path> files = new ArrayList<>();
        try (var s = Files.newDirectoryStream(dataDir, "dataset_*.csv")) { for (Path p : s) files.add(p); }
        files.sort(Comparator.comparingInt(p -> Integer.parseInt(p.getFileName().toString().replaceAll("\\D", ""))));

        int[] warm = readFreq(files.get(0));                // warm-up so the JIT does not distort the first timing
        for (int k = 0; k < 5; k++) { cubic(warm); knuth(warm); }

        StringBuilder csv = new StringBuilder("n,cubic_ms,knuth_ms,speedup,optimal_cost,balanced_cost,reduction_percent,costs_match\n");
        System.out.printf("%-7s %12s %12s %9s %14s %14s %10s %7s%n",
                "n", "O(n^3) ms", "Knuth ms", "speedup", "optimal cost", "balanced cost", "reduction", "match");
        for (Path p : files) {
            int[] f = readFreq(p); int n = f.length;
            long t0 = System.nanoTime(); long c1 = cubic(f);  long t1 = System.nanoTime();
            long c2 = knuth(f);                               long t2 = System.nanoTime();
            double ms1 = (t1 - t0) / 1e6, ms2 = (t2 - t1) / 1e6;
            long bal = balanced(f, 0, n - 1, 1);
            double red = 100.0 * (bal - c1) / bal;
            boolean ok = c1 == c2;
            System.out.printf("%-7d %12.2f %12.2f %8.1fx %14d %14d %9.2f%% %7s%n", n, ms1, ms2, ms1 / ms2, c1, bal, red, ok);
            csv.append(String.format(Locale.US, "%d,%.2f,%.2f,%.1f,%d,%d,%.2f,%s%n", n, ms1, ms2, ms1 / ms2, c1, bal, red, ok));
        }
        Files.writeString(outDir.resolve("benchmark_results.csv"), csv.toString());
        System.out.println("\nSaved " + outDir.resolve("benchmark_results.csv"));
    }
}
