import java.io.*;
import java.util.*;

/** Generates the benchmark datasets.  Run from the repository root:  java src/GenerateData.java */
public class GenerateData {
    public static void main(String[] args) throws IOException {
        int[] sizes = {100, 200, 500, 1000, 2000, 4000};
        Random rnd = new Random(42);                       // fixed seed -> reproducible files
        new File("data").mkdirs();
        for (int n : sizes) {
            try (PrintWriter out = new PrintWriter("data/dataset_" + n + ".csv")) {
                out.println("key,frequency");
                for (int i = 1; i <= n; i++)               // distinct sorted keys, random positive frequencies
                    out.println(i + "," + (1 + rnd.nextInt(1000)));
            }
        }
        try (PrintWriter out = new PrintWriter("data/sample.csv")) {   // the 4-key example from the report
            out.println("key,frequency");
            out.println("10,4"); out.println("20,2"); out.println("30,6"); out.println("40,3");
        }
        System.out.println("Datasets written to data/");
    }
}
