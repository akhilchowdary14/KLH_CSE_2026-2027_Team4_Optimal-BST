import java.util.*;

public class OptimalBST {

    /* ---------- Module 1: Node + input validation ---------- */
    static class Node {
        int key, freq;
        Node left, right;
        Node(int key, int freq) { this.key = key; this.freq = freq; }
    }

    static void validate(int[] keys, int[] freq) {
        if (keys.length == 0 || keys.length != freq.length)
            throw new IllegalArgumentException(
                "Keys and frequencies must be non-empty and of equal length.");
        Set<Integer> seen = new HashSet<>();
        for (int i = 0; i < keys.length; i++) {
            if (!seen.add(keys[i]))
                throw new IllegalArgumentException("Duplicate key found: " + keys[i]);
            if (freq[i] <= 0)
                throw new IllegalArgumentException(
                    "Frequency must be positive for key " + keys[i]);
        }
    }

    /* ---------- Module 2: Interval DP (cost + root tables) ---------- */
    static int[][] cost, root;

    static int computeOptimalCost(int[] freq) {
        int n = freq.length;
        int[] prefix = new int[n + 1];                 // prefix[i] = sum of freq[0..i-1]
        for (int i = 0; i < n; i++) prefix[i + 1] = prefix[i] + freq[i];

        cost = new int[n][n];
        root = new int[n][n];
        for (int i = 0; i < n; i++) {                  // base case: single key
            cost[i][i] = freq[i];
            root[i][i] = i;
        }
        for (int len = 2; len <= n; len++) {           // increasing interval length
            for (int i = 0; i + len - 1 < n; i++) {
                int j = i + len - 1;
                int sum = prefix[j + 1] - prefix[i];   // total frequency of keys i..j
                cost[i][j] = Integer.MAX_VALUE;
                for (int r = i; r <= j; r++) {         // try every key as root
                    int left  = (r > i) ? cost[i][r - 1] : 0;
                    int right = (r < j) ? cost[r + 1][j] : 0;
                    int c = left + right + sum;
                    if (c < cost[i][j]) { cost[i][j] = c; root[i][j] = r; }
                }
            }
        }
        return cost[0][n - 1];
    }

    /* ---------- Module 3: Tree reconstruction from root table ---------- */
    static Node buildTree(int[] keys, int[] freq, int i, int j) {
        if (i > j) return null;
        int r = root[i][j];
        Node node = new Node(keys[r], freq[r]);
        node.left  = buildTree(keys, freq, i, r - 1);
        node.right = buildTree(keys, freq, r + 1, j);
        return node;
    }

    /* ---------- Module 4: Display + verification ---------- */
    static void printTree(Node node, String prefix, boolean isLeft, boolean isRoot) {
        if (node == null) return;
        if (isRoot) System.out.println("ROOT -> " + node.key + " (freq " + node.freq + ")");
        else        System.out.println(prefix + (isLeft ? "L--- " : "R--- ")
                           + node.key + " (freq " + node.freq + ")");
        String childPrefix = isRoot ? "   " : prefix + "     ";
        printTree(node.left,  childPrefix, true,  false);
        printTree(node.right, childPrefix, false, false);
    }

    // sum(freq * depth), root at depth 1
    static int weightedCost(Node node, int depth) {
        if (node == null) return 0;
        return node.freq * depth + weightedCost(node.left, depth + 1)
                                 + weightedCost(node.right, depth + 1);
    }

    // frequency-blind baseline: middle key of each range becomes the root
    static Node balancedTree(int[] keys, int[] freq, int lo, int hi) {
        if (lo > hi) return null;
        int mid = (lo + hi) / 2;
        Node n = new Node(keys[mid], freq[mid]);
        n.left = balancedTree(keys, freq, lo, mid - 1);
        n.right = balancedTree(keys, freq, mid + 1, hi);
        return n;
    }

    static void run(String title, int[] keys, int[] freq) {
        System.out.println("=== " + title + " ===");
        try { validate(keys, freq); }
        catch (IllegalArgumentException e) {
            System.out.println("Input error: " + e.getMessage() + "\n"); return;
        }

        // sort keys (and carry frequencies along) so that BST order holds
        Integer[] idx = new Integer[keys.length];
        for (int i = 0; i < idx.length; i++) idx[i] = i;
        Arrays.sort(idx, Comparator.comparingInt(a -> keys[a]));
        int[] k = new int[keys.length], f = new int[keys.length];
        for (int i = 0; i < idx.length; i++) { k[i] = keys[idx[i]]; f[i] = freq[idx[i]]; }

        System.out.println("Keys        : " + Arrays.toString(k));
        System.out.println("Frequencies : " + Arrays.toString(f));
        int total = Arrays.stream(f).sum();
        int best = computeOptimalCost(f);
        Node tree = buildTree(k, f, 0, k.length - 1);

        System.out.println("\nOptimal BST structure:");
        printTree(tree, "", false, true);

        System.out.println("\nMinimum weighted search cost : " + best);
        System.out.println("Sum of frequencies           : " + total);
        System.out.printf ("Average search cost          : %.2f comparisons%n",
                          (double) best / total);
        System.out.println("Cost re-computed from tree   : " + weightedCost(tree, 1));
        int bal = weightedCost(balancedTree(k, f, 0, k.length - 1), 1);
        System.out.printf ("Balanced (frequency-blind)   : %d  (avg %.2f)%n%n",
                          bal, (double) bal / total);
    }

    public static void main(String[] args) {
        run("Test 1: 4 keys",
            new int[]{10, 20, 30, 40}, new int[]{4, 2, 6, 3});
        run("Test 2: 6 keys (unsorted)",
            new int[]{50, 10, 40, 20, 60, 30}, new int[]{3, 34, 8, 12, 2, 21});
        run("Test 3: duplicate key",
            new int[]{10, 20, 20, 40}, new int[]{4, 2, 6, 3});
    }
}
