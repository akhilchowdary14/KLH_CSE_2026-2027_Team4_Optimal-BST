# Optimal Binary Search Tree — Web Working Model

A browser-based DSA project that constructs an Optimal Binary Search Tree using interval Dynamic Programming.

## Features
- Accepts distinct, sorted keys and positive search frequencies.
- Calculates the minimum weighted search cost using Dynamic Programming.
- Reconstructs and visualizes the optimal BST.
- Displays optimal root, minimum cost, average cost, preorder/inorder traversal, and each key's cost contribution.
- Includes validation and a sample input.

## Technology
- HTML
- CSS
- JavaScript (no external libraries required)

## Run in VS Code
1. Extract the project folder.
2. Open VS Code.
3. Select **File → Open Folder** and choose `Optimal_BST_Web_App`.
4. Install the **Live Server** extension by Ritwick Dey if it is not already installed.
5. Open `index.html`.
6. Right-click inside the editor and choose **Open with Live Server**.
7. Your browser should open the application. If it does not, click **Go Live** in the VS Code status bar.

You can also open `index.html` directly in a browser, but Live Server is recommended for the demonstration.

## Sample input
Keys: `A B C D`

Frequencies: `4 2 6 3`

Expected minimum cost: `26`

Expected average cost: `26 / 15 = 1.73`

Expected optimal tree:
```text
        C
       / \\
      A   D
       \\
        B
```

## Algorithm
For each interval of sorted keys, try every key as the root. The recurrence is:

`cost[i][j] = sum(freq[i..j]) + min(cost[i][r-1] + cost[r+1][j])`

Empty subtree cost is zero. The stored root table is used to reconstruct the tree.

- Time complexity: `O(n^3)`
- Space complexity: `O(n^2)`

## Note about the implementation
This web demo implements the algorithm in JavaScript so the website can run in a browser. If the course submission specifically requires the algorithm implementation to be in Java, retain the Java console version as well and confirm with your faculty whether a browser UI is acceptable.
