const form = document.getElementById("obstForm");
const keysInput = document.getElementById("keysInput");
const freqInput = document.getElementById("freqInput");
const errorMessage = document.getElementById("errorMessage");
const sampleBtn = document.getElementById("sampleBtn");

function parseList(value) {
  return value.trim().split(/[,\s]+/).filter(Boolean);
}

function calculateOBST(keys, frequencies) {
  const n = keys.length;
  const cost = Array.from({ length: n }, () => Array(n).fill(0));
  const root = Array.from({ length: n }, () => Array(n).fill(-1));
  const prefix = Array(n + 1).fill(0);

  for (let i = 0; i < n; i++) prefix[i + 1] = prefix[i] + frequencies[i];

  for (let i = 0; i < n; i++) {
    cost[i][i] = frequencies[i];
    root[i][i] = i;
  }

  for (let length = 2; length <= n; length++) {
    for (let i = 0; i <= n - length; i++) {
      const j = i + length - 1;
      const totalFrequency = prefix[j + 1] - prefix[i];
      cost[i][j] = Infinity;

      for (let r = i; r <= j; r++) {
        const leftCost = r > i ? cost[i][r - 1] : 0;
        const rightCost = r < j ? cost[r + 1][j] : 0;
        const currentCost = leftCost + rightCost + totalFrequency;

        if (currentCost < cost[i][j]) {
          cost[i][j] = currentCost;
          root[i][j] = r;
        }
      }
    }
  }

  function build(i, j) {
    if (i > j) return null;
    const r = root[i][j];
    return {
      key: keys[r],
      frequency: frequencies[r],
      index: r,
      left: build(i, r - 1),
      right: build(r + 1, j)
    };
  }

  return {
    tree: build(0, n - 1),
    minCost: cost[0][n - 1],
    totalFrequency: prefix[n],
    rootTable: root
  };
}

function createTreeHTML(node, rootKey) {
  if (!node) return "";
  const rootClass = node.key === rootKey ? " root-node" : "";
  const left = node.left ? `<li>${createTreeHTML(node.left, rootKey)}</li>` : "";
  const right = node.right ? `<li>${createTreeHTML(node.right, rootKey)}</li>` : "";
  const children = (left || right) ? `<ul>${left || '<li class="empty-child"></li>'}${right || '<li class="empty-child"></li>'}</ul>` : "";
  return `<div class="node${rootClass}"><span class="node-key">${escapeHTML(node.key)}</span><span class="node-freq">freq: ${node.frequency}</span></div>${children}`;
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[ch]);
}

function traverse(node, order, output) {
  if (!node) return;
  if (order === "pre") output.push(node.key);
  traverse(node.left, order, output);
  if (order === "in") output.push(node.key);
  traverse(node.right, order, output);
}

function collectDepths(node, depth = 1, result = []) {
  if (!node) return result;
  result.push({ key: node.key, frequency: node.frequency, depth, contribution: node.frequency * depth });
  collectDepths(node.left, depth + 1, result);
  collectDepths(node.right, depth + 1, result);
  return result;
}

function renderResults(keys, frequencies, result) {
  const rootKey = result.tree.key;
  document.getElementById("rootValue").textContent = rootKey;
  document.getElementById("costValue").textContent = result.minCost;
  document.getElementById("averageValue").textContent = (result.minCost / result.totalFrequency).toFixed(2);
  document.getElementById("totalFreq").textContent = result.totalFrequency;
  document.getElementById("keyCount").textContent = keys.length;

  document.getElementById("treeCanvas").innerHTML =
    `<div class="tree"><ul><li>${createTreeHTML(result.tree, rootKey)}</li></ul></div>`;

  const preorder = [], inorder = [];
  traverse(result.tree, "pre", preorder);
  traverse(result.tree, "in", inorder);
  document.getElementById("preorderValue").textContent = preorder.join(" ");
  document.getElementById("inorderValue").textContent = inorder.join(" ");

  const breakdown = collectDepths(result.tree).sort((a, b) => keys.indexOf(a.key) - keys.indexOf(b.key));
  document.getElementById("costBreakdown").innerHTML = breakdown.map(item =>
    `<span class="cost-chip"><strong>${escapeHTML(item.key)}</strong>: ${item.frequency} × ${item.depth} = <strong>${item.contribution}</strong></span>`
  ).join("");
}

function runModel(event) {
  if (event) event.preventDefault();
  errorMessage.textContent = "";

  const keys = parseList(keysInput.value);
  const frequenciesText = parseList(freqInput.value);
  const frequencies = frequenciesText.map(Number);

  if (!keys.length) {
    errorMessage.textContent = "Enter at least one key.";
    return;
  }
  if (keys.length !== frequencies.length) {
    errorMessage.textContent = "Enter exactly one frequency for each key.";
    return;
  }
  if (keys.length > 40) {
    errorMessage.textContent = "For this demo, please use 40 keys or fewer.";
    return;
  }
  if (new Set(keys).size !== keys.length) {
    errorMessage.textContent = "Keys must be distinct. Remove duplicate keys.";
    return;
  }
  for (let i = 0; i < keys.length - 1; i++) {
    if (keys[i].localeCompare(keys[i + 1], undefined, { numeric: true, sensitivity: "base" }) >= 0) {
      errorMessage.textContent = "Keys must be entered in ascending order (for example: A B C D).";
      return;
    }
  }
  if (frequencies.some(value => !Number.isSafeInteger(value) || value <= 0)) {
    errorMessage.textContent = "Frequencies must be positive whole numbers.";
    return;
  }

  const result = calculateOBST(keys, frequencies);
  renderResults(keys, frequencies, result);
}

form.addEventListener("submit", runModel);
sampleBtn.addEventListener("click", () => {
  keysInput.value = "A B C D";
  freqInput.value = "4 2 6 3";
  runModel();
});

runModel();
